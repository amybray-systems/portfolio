# Data Dictionary (Fin Ops Suite)

| Column             | Type    | Required | Description                                       | Example       |
|--------------------|---------|----------|---------------------------------------------------|---------------|
| Candidate_Name     | string  | yes      | Worker / contractor full name                     | John Doe      |
| Client_Bill_Amount | number  | yes      | Billed amount to client for the week (USD)        | 1500          |
| TotalHours         | number  | yes      | Total hours worked in the week                    | 40            |
| Department         | string  | yes      | Owning cost-center / department                   | Engineering   |
| Week_Ending        | date    | yes      | Week ending date (MM/DD/YYYY)                     | 1/7/2024      |

**Notes**
- Dates: supply as `MM/DD/YYYY`.
- One row per worker per week. Duplicate rows will be flagged.
- Values should be non-negative. Hours typically in [0, 80].
