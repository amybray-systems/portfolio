Fin Ops Suite — Upload Templates
=================================

Files included
- vendor_upload_template.csv   -> Blank CSV with headers
- data_dictionary.md           -> Column definitions and examples

How to use
1) Copy `vendor_upload_template.csv`.
2) Paste your data underneath the header row using the definitions in data_dictionary.md.
3) Save as CSV and upload to Fin Ops Suite (beta).
